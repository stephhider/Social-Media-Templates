Social Media Cheat Sheet in PSD format. All of the sizes are marked, full size and a smart object for easy editing. Some items are videos or other placement type of material. Headers have viewable areas marked.


Dimensions and Idea to take this even further is from info graphic found here: hub.am/UL1jy2 

Cheers!

http://stephaniehider.com
@stephhider

